"""WebSocket connection manager for game broadcast."""

from typing import Dict, Set
from fastapi import WebSocket
import asyncio
import weakref


class ConnectionManager:
    """Manages WebSocket connections per game room.

    Connection lifecycle:
    - connect(game_id, websocket): Register a new spectator connection
    - disconnect(game_id, websocket): Unregister; clean up empty rooms
    - broadcast(game_id, message): Send JSON to ALL connected clients for a game
    """

    def __init__(self):
        # game_id -> set of weakref to WebSocket
        self._rooms: Dict[str, Set[weakref.ref]] = {}
        self._lock = asyncio.Lock()

    async def connect(self, game_id: str, websocket: WebSocket):
        """Register a new WebSocket connection for a game room."""
        await websocket.accept()
        async with self._lock:
            if game_id not in self._rooms:
                self._rooms[game_id] = set()
            self._rooms[game_id].add(weakref.ref(websocket))

    async def disconnect(self, game_id: str, websocket: WebSocket):
        """Unregister a WebSocket connection and clean up empty rooms."""
        async with self._lock:
            if game_id in self._rooms:
                # Remove dead weakrefs and the disconnected websocket
                self._rooms[game_id] = {
                    ref for ref in self._rooms[game_id]
                    if ref() is not None and ref() is not websocket
                }
                if not self._rooms[game_id]:
                    del self._rooms[game_id]

    async def broadcast(self, game_id: str, message: dict):
        """Broadcast a JSON message to all connected clients for a game."""
        if game_id not in self._rooms:
            return

        # Collect live connections
        live_connections = []
        async with self._lock:
            for ref in list(self._rooms[game_id]):
                ws = ref()
                if ws is not None:
                    live_connections.append(ws)

        if not live_connections:
            return

        # Send concurrently with timeout
        async def send_safe(ws, msg):
            try:
                await asyncio.wait_for(ws.send_json(msg), timeout=5.0)
            except Exception:
                pass  # Client may have disconnected during send

        await asyncio.gather(
            *[send_safe(ws, message) for ws in live_connections],
            return_exceptions=True
        )

    def get_connection_count(self, game_id: str) -> int:
        """Return number of active connections for a game."""
        if game_id not in self._rooms:
            return 0
        return sum(1 for ref in self._rooms[game_id] if ref() is not None)