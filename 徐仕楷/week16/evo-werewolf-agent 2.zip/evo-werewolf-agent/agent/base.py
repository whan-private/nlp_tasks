
from agents import Agent, Runner
from agents import set_default_openai_api, set_tracing_disabled, set_default_openai_client
from openai import AsyncOpenAI
from schema.system_config import load_system_config

set_default_openai_api("chat_completions")
set_tracing_disabled(True)

config = load_system_config("config/system_config.json")

# Create client with explicit key so SDK uses it
client = AsyncOpenAI(api_key=config.api_key, base_url=config.base_url)
set_default_openai_client(client)


class BaseAgent:
    def __init__(self):
        self.agent = Agent(
            name="",
            model=config.default_model,
            instructions="你好",
        )

    async def run(self, input: str):
        result = await Runner.run(self.agent, input)
        return result.final_output
