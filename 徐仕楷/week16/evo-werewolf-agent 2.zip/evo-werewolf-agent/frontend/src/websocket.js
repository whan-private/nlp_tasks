/**
 * WebSocket client for real-time game updates.
 * Handles connection lifecycle, reconnection with exponential backoff,
 * and message dispatching to registered handlers.
 */

const WS_READY_STATE = { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 }

export class GameWebSocket {
  constructor(gameId, onMessage, options = {}) {
    this.gameId = gameId
    this.onMessage = onMessage
    this.reconnectInterval = options.reconnectInterval || 1000
    this.maxReconnectInterval = options.maxReconnectInterval || 30000
    this.maxRetries = options.maxRetries || 10

    this._ws = null
    this._reconnectCount = 0
    this._reconnectTimer = null
    this._shouldReconnect = true
  }

  get baseUrl() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    return `${protocol}//${window.location.host}`
  }

  connect() {
    return new Promise((resolve, reject) => {
      this._shouldReconnect = true
      this._ws = new WebSocket(`${this.baseUrl}/ws/games/${this.gameId}`)

      this._ws.onopen = () => {
        this._reconnectCount = 0
        resolve()
      }

      this._ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          this.onMessage(data)
        } catch (e) {
          console.error('WS message parse error:', e)
        }
      }

      this._ws.onclose = (event) => {
        if (this._shouldReconnect && this._reconnectCount < this.maxRetries) {
          this._scheduleReconnect()
        }
        this._ws = null
      }

      this._ws.onerror = (error) => {
        console.error('WS error:', error)
        reject(error)
      }
    })
  }

  _scheduleReconnect() {
    const delay = Math.min(
      this.reconnectInterval * Math.pow(2, this._reconnectCount) + Math.random() * 1000,
      this.maxReconnectInterval
    )
    this._reconnectCount++

    this._reconnectTimer = setTimeout(() => {
      if (this._shouldReconnect) {
        this.connect().catch(() => {})
      }
    }, delay)
  }

  send(data) {
    if (this._ws && this._ws.readyState === WS_READY_STATE.OPEN) {
      this._ws.send(JSON.stringify(data))
    }
  }

  ping() {
    this.send({ type: 'ping' })
  }

  disconnect() {
    this._shouldReconnect = false
    if (this._reconnectTimer) {
      clearTimeout(this._reconnectTimer)
      this._reconnectTimer = null
    }
    if (this._ws) {
      this._ws.close()
      this._ws = null
    }
  }
}